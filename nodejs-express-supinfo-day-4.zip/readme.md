FERREIRA Orlann & TOLA Duke

Create a .env file: 
    EXPRESS_PORT = 3000
    JWT_KEY = "P46PHI65EFmkyUTqt2b00IUC3hOIl3k8Ogiwu0qAPm7MbOdqekdOPjdiqhfiS4jP"
    DB_URL = "YOUR MONGODB URL"
    HASH_SALT = "$2b$10$ikTx0RfnbUi/YiZB/MuVvO"